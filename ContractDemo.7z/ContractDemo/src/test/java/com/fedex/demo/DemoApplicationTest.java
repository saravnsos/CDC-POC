/*package com.fedex.demo;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.client.model.ShipShipmentInputVO;

@RunWith(SpringRunner.class)

@SpringBootTest(classes=DemoApplication.class,webEnvironment=SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
@AutoConfigureStubRunner(
		repositoryRoot="https://nexus.prod.cloud.fedex.com:8443/nexus/content/repositories/cxs-repository/",
		ids = {"fedex.cxs.shpc:SHPC:1.0.0.1-RELEASE:stub:9001","fedex.cxs.shpc:SHPC1:1.0.0.1-SNAPSHOT:stub:9001"}
		)

public class DemoApplicationTest {

	@Autowired
	MockMvc mockMvc;

	@Autowired
	DemoController demoController;

	@Test
	public void testDemo()
	{
		demoController.port=9001;
		ShipShipmentInputVO input = new ShipShipmentInputVO();

		try {
			input = (ShipShipmentInputVO) JsonToJavaObjectsUtil.getWithObjectMapper(ShipShipmentInputVO.class,"shipmentrequest.json");
			System.out.println("Input Object##########"+new ObjectMapper().writeValueAsString(input));
			//MvcResult mvcResult=
					
					mockMvc.perform(MockMvcRequestBuilders.post("/shipments")
							.contentType("application/json")
							.content(new ObjectMapper().writeValueAsString(input)))
							.andDo(print())
							.andExpect(status().isOk());
							
					//.andReturn();
			//System.out.println("MVCResult"+mvcResult);
		} catch (JsonProcessingException e) {
			
			System.out.println("Exception in testDemo() JsonProcessingException");
			e.printStackTrace();
		} catch (Exception e) {
		
			System.out.println("Exception in testDemo()");
			e.printStackTrace();
		}
	}

}
*/