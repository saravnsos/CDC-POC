package io.swagger.client.api;

import io.swagger.client.ApiClient;

import io.swagger.client.model.CancelShipmentInputVO;
import io.swagger.client.model.CancelShipmentOutputVO;
import io.swagger.client.model.CancelTagInputVO;
import io.swagger.client.model.CreateTagInputVO;
import io.swagger.client.model.EndOfDayCloseOutputVO;
import io.swagger.client.model.EndofDayCloseInputVO;
import io.swagger.client.model.GetMailRoomPendingConfirmationOutputVO;
import io.swagger.client.model.GetReprintInfoOutputVO;
import io.swagger.client.model.PSDUShipmentInputVO;
import io.swagger.client.model.PSDUShipmentOutputVO;
import io.swagger.client.model.PendingShipmentOutputVO;
import io.swagger.client.model.ShipShipmentInputVO;
import io.swagger.client.model.ShipShipmentOutputVODescription;
import io.swagger.client.model.ValidateShipmentInputVO;
import io.swagger.client.model.ValidateShipmentOutputVO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2019-06-17T13:18:14.655+05:30")
@Component("io.swagger.client.api.ShipmentControllerV3Api")
public class ShipmentControllerV3Api {
    private ApiClient apiClient;

    public ShipmentControllerV3Api() {
        this(new ApiClient());
    }

    @Autowired
    public ShipmentControllerV3Api(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * cancelShipment
     * 
     * <p><b>200</b> - Success
     * <p><b>201</b> - Created
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param shipmentid shipmentid
     * @param input input
     * @return CancelShipmentOutputVO
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public CancelShipmentOutputVO cancelShipment(String shipmentid, CancelShipmentInputVO input) throws RestClientException {
        Object postBody = input;
        
        // verify the required parameter 'shipmentid' is set
        if (shipmentid == null) {
            throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Missing the required parameter 'shipmentid' when calling cancelShipment");
        }
        
        // create path and map variables
        final Map<String, Object> uriVariables = new HashMap<String, Object>();
        uriVariables.put("shipmentid", shipmentid);
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/shipments/{shipmentid}").buildAndExpand(uriVariables).toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<CancelShipmentOutputVO> returnType = new ParameterizedTypeReference<CancelShipmentOutputVO>() {};
        return apiClient.invokeAPI(path, HttpMethod.PUT, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * cancelTag
     * 
     * <p><b>200</b> - Success
     * <p><b>201</b> - Created
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param shipmentid shipmentid
     * @param cancelTagInputVO cancelTagInputVO
     * @return ShipShipmentOutputVODescription
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public ShipShipmentOutputVODescription cancelTagUsingPUT(String shipmentid, CancelTagInputVO cancelTagInputVO) throws RestClientException {
        Object postBody = cancelTagInputVO;
        
        // verify the required parameter 'shipmentid' is set
        if (shipmentid == null) {
            throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Missing the required parameter 'shipmentid' when calling cancelTagUsingPUT");
        }
        
        // create path and map variables
        final Map<String, Object> uriVariables = new HashMap<String, Object>();
        uriVariables.put("shipmentid", shipmentid);
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/shipments/tag/{shipmentid}").buildAndExpand(uriVariables).toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<ShipShipmentOutputVODescription> returnType = new ParameterizedTypeReference<ShipShipmentOutputVODescription>() {};
        return apiClient.invokeAPI(path, HttpMethod.PUT, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * getMailroomPendingConfirmation
     * 
     * <p><b>200</b> - Success
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param pendingshipmentid pendingshipmentid
     * @param contenttype contenttype
     * @return GetMailRoomPendingConfirmationOutputVO
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public GetMailRoomPendingConfirmationOutputVO getMailroomPendingConfirmationUsingGET(String pendingshipmentid, String contenttype) throws RestClientException {
        Object postBody = null;
        
        // verify the required parameter 'pendingshipmentid' is set
        if (pendingshipmentid == null) {
            throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Missing the required parameter 'pendingshipmentid' when calling getMailroomPendingConfirmationUsingGET");
        }
        
        // create path and map variables
        final Map<String, Object> uriVariables = new HashMap<String, Object>();
        uriVariables.put("pendingshipmentid", pendingshipmentid);
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/shipments/mailroompendingconfirmation/{pendingshipmentid}").buildAndExpand(uriVariables).toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();
        
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "contenttype", contenttype));

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<GetMailRoomPendingConfirmationOutputVO> returnType = new ParameterizedTypeReference<GetMailRoomPendingConfirmationOutputVO>() {};
        return apiClient.invokeAPI(path, HttpMethod.GET, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * Its a create tag to be called
     * This Rest API allows Document to create tag to be called 
     * <p><b>200</b> - Success
     * <p><b>201</b> - Created
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param createTagInputVO createTagInputVO
     * @return ShipShipmentOutputVODescription
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public ShipShipmentOutputVODescription itsACreateTagToBeCalled(CreateTagInputVO createTagInputVO) throws RestClientException {
        Object postBody = createTagInputVO;
        
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/shipments/tag").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<ShipShipmentOutputVODescription> returnType = new ParameterizedTypeReference<ShipShipmentOutputVODescription>() {};
        return apiClient.invokeAPI(path, HttpMethod.PUT, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * performEndOfDayClose
     * 
     * <p><b>200</b> - Success
     * <p><b>201</b> - Created
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param input input
     * @return EndOfDayCloseOutputVO
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public EndOfDayCloseOutputVO performEndOfDayCloseUsingPUT(EndofDayCloseInputVO input) throws RestClientException {
        Object postBody = input;
        
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/shipments/endofdayclose").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<EndOfDayCloseOutputVO> returnType = new ParameterizedTypeReference<EndOfDayCloseOutputVO>() {};
        return apiClient.invokeAPI(path, HttpMethod.PUT, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * processPendingShipment
     * 
     * <p><b>200</b> - Success
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param pendingshipmentid pendingshipmentid
     * @return PendingShipmentOutputVO
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public PendingShipmentOutputVO processPendingShipmentUsingGET(String pendingshipmentid) throws RestClientException {
        Object postBody = null;
        
        // verify the required parameter 'pendingshipmentid' is set
        if (pendingshipmentid == null) {
            throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Missing the required parameter 'pendingshipmentid' when calling processPendingShipmentUsingGET");
        }
        
        // create path and map variables
        final Map<String, Object> uriVariables = new HashMap<String, Object>();
        uriVariables.put("pendingshipmentid", pendingshipmentid);
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/shipments/process/{pendingshipmentid}").buildAndExpand(uriVariables).toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<PendingShipmentOutputVO> returnType = new ParameterizedTypeReference<PendingShipmentOutputVO>() {};
        return apiClient.invokeAPI(path, HttpMethod.GET, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * reprintInfo
     * 
     * <p><b>200</b> - Success
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param trackingnumber trackingnumber
     * @return GetReprintInfoOutputVO
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public GetReprintInfoOutputVO reprintInfo(String trackingnumber) throws RestClientException {
        Object postBody = null;
        
        // verify the required parameter 'trackingnumber' is set
        if (trackingnumber == null) {
            throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Missing the required parameter 'trackingnumber' when calling reprintInfo");
        }
        
        // create path and map variables
        final Map<String, Object> uriVariables = new HashMap<String, Object>();
        uriVariables.put("trackingnumber", trackingnumber);
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/shipments/reprintinfo/{trackingnumber}").buildAndExpand(uriVariables).toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<GetReprintInfoOutputVO> returnType = new ParameterizedTypeReference<GetReprintInfoOutputVO>() {};
        return apiClient.invokeAPI(path, HttpMethod.GET, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * retrievePSDUShipments
     * 
     * <p><b>200</b> - Success
     * <p><b>201</b> - Created
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param inputVO inputVO
     * @return PSDUShipmentOutputVO
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public PSDUShipmentOutputVO retrievePSDUShipments(PSDUShipmentInputVO inputVO) throws RestClientException {
        Object postBody = inputVO;
        
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/shipments/documents/incomplete/info").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<PSDUShipmentOutputVO> returnType = new ParameterizedTypeReference<PSDUShipmentOutputVO>() {};
        return apiClient.invokeAPI(path, HttpMethod.POST, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * shipShipment
     * 
     * <p><b>200</b> - Success
     * <p><b>201</b> - Created
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param input input
     * @return ShipShipmentOutputVODescription
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public ShipShipmentOutputVODescription shipShipment(ShipShipmentInputVO input) throws RestClientException {
        Object postBody = input;
        
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/shipments").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<ShipShipmentOutputVODescription> returnType = new ParameterizedTypeReference<ShipShipmentOutputVODescription>() {};
        return apiClient.invokeAPI(path, HttpMethod.PUT, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * shipShipment
     * 
     * <p><b>200</b> - Success
     * <p><b>201</b> - Created
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param input input
     * @return ShipShipmentOutputVODescription
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public ShipShipmentOutputVODescription shipShipment1(ShipShipmentInputVO input) throws RestClientException {
        Object postBody = input;
        
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/shipments").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<ShipShipmentOutputVODescription> returnType = new ParameterizedTypeReference<ShipShipmentOutputVODescription>() {};
        return apiClient.invokeAPI(path, HttpMethod.POST, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * validateShipment
     * 
     * <p><b>200</b> - Success
     * <p><b>201</b> - Created
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param validateShipmentInputVO validateShipmentInputVO
     * @return ValidateShipmentOutputVO
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public ValidateShipmentOutputVO validateShipmentUsingPOST(ValidateShipmentInputVO validateShipmentInputVO) throws RestClientException {
        Object postBody = validateShipmentInputVO;
        
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/shipments/validate").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<ValidateShipmentOutputVO> returnType = new ParameterizedTypeReference<ValidateShipmentOutputVO>() {};
        return apiClient.invokeAPI(path, HttpMethod.POST, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
}
