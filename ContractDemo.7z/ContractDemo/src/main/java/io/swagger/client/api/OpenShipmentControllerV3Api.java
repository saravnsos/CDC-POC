package io.swagger.client.api;

import io.swagger.client.ApiClient;

import io.swagger.client.model.AutoCompleteOpenShipmentDispatchInputVO;
import io.swagger.client.model.AutoCompleteOpenShipmentDispatchOutputVO;
import io.swagger.client.model.AutomaticallyCompleteOpenShipmentOutput;
import io.swagger.client.model.CompleteOpenShipmentInputVO;
import io.swagger.client.model.CompleteOpenShipmentOutput;
import io.swagger.client.model.RetrieveOpenShipmentHistoryOutputVO;
import io.swagger.client.model.RetrieveOpenShipmentOutputVODescription;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2019-06-17T13:18:14.655+05:30")
@Component("io.swagger.client.api.OpenShipmentControllerV3Api")
public class OpenShipmentControllerV3Api {
    private ApiClient apiClient;

    public OpenShipmentControllerV3Api() {
        this(new ApiClient());
    }

    @Autowired
    public OpenShipmentControllerV3Api(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Automatically Complete OpenShipment by printer type
     * 
     * <p><b>200</b> - Success
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param printertype printer type
     * @param uniqueuserid Unique UserID
     * @return AutomaticallyCompleteOpenShipmentOutput
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public AutomaticallyCompleteOpenShipmentOutput automaticallyCompleteOpenShipmentByPrinterType(String printertype, String uniqueuserid) throws RestClientException {
        Object postBody = null;
        
        // verify the required parameter 'printertype' is set
        if (printertype == null) {
            throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Missing the required parameter 'printertype' when calling automaticallyCompleteOpenShipmentByPrinterType");
        }
        
        // create path and map variables
        final Map<String, Object> uriVariables = new HashMap<String, Object>();
        uriVariables.put("printertype", printertype);
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/openshipments/automaticallycomplete/{printertype}").buildAndExpand(uriVariables).toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();
        
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "uniqueuserid", uniqueuserid));

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<AutomaticallyCompleteOpenShipmentOutput> returnType = new ParameterizedTypeReference<AutomaticallyCompleteOpenShipmentOutput>() {};
        return apiClient.invokeAPI(path, HttpMethod.GET, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * Automatically Complete OpenShipment dispatch
     * 
     * <p><b>200</b> - Success
     * <p><b>201</b> - Created
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param automaticallyCompleteOpenShipmentDispatchInputVO automaticallyCompleteOpenShipmentDispatchInputVO
     * @return AutoCompleteOpenShipmentDispatchOutputVO
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public AutoCompleteOpenShipmentDispatchOutputVO automaticallyCompleteOpenShipmentDispatch(AutoCompleteOpenShipmentDispatchInputVO automaticallyCompleteOpenShipmentDispatchInputVO) throws RestClientException {
        Object postBody = automaticallyCompleteOpenShipmentDispatchInputVO;
        
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/openshipments/automaticallycomplete").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<AutoCompleteOpenShipmentDispatchOutputVO> returnType = new ParameterizedTypeReference<AutoCompleteOpenShipmentDispatchOutputVO>() {};
        return apiClient.invokeAPI(path, HttpMethod.PUT, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * complete openshipments
     * 
     * <p><b>200</b> - Success
     * <p><b>201</b> - Created
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param completeOpenShipmentInputVO completeOpenShipmentInputVO
     * @return CompleteOpenShipmentOutput
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public CompleteOpenShipmentOutput completeopenshipments(CompleteOpenShipmentInputVO completeOpenShipmentInputVO) throws RestClientException {
        Object postBody = completeOpenShipmentInputVO;
        
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/openshipments").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<CompleteOpenShipmentOutput> returnType = new ParameterizedTypeReference<CompleteOpenShipmentOutput>() {};
        return apiClient.invokeAPI(path, HttpMethod.PUT, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * retrieve openshipment history
     * 
     * <p><b>200</b> - Success
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param uniqueuserid uniqueuserid
     * @return RetrieveOpenShipmentHistoryOutputVO
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public RetrieveOpenShipmentHistoryOutputVO retrieveOpenshipmentHistory(String uniqueuserid) throws RestClientException {
        Object postBody = null;
        
        // verify the required parameter 'uniqueuserid' is set
        if (uniqueuserid == null) {
            throw new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Missing the required parameter 'uniqueuserid' when calling retrieveOpenshipmentHistory");
        }
        
        // create path and map variables
        final Map<String, Object> uriVariables = new HashMap<String, Object>();
        uriVariables.put("uniqueuserid", uniqueuserid);
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/openshipments/shiphistory/{uniqueuserid}").buildAndExpand(uriVariables).toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<RetrieveOpenShipmentHistoryOutputVO> returnType = new ParameterizedTypeReference<RetrieveOpenShipmentHistoryOutputVO>() {};
        return apiClient.invokeAPI(path, HttpMethod.GET, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * retrieve openshipments
     * This Rest API allows Document to Retrieve Open Shipments
     * <p><b>200</b> - Success
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @return RetrieveOpenShipmentOutputVODescription
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public RetrieveOpenShipmentOutputVODescription retrieveopenshipments() throws RestClientException {
        Object postBody = null;
        
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/openshipments").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<RetrieveOpenShipmentOutputVODescription> returnType = new ParameterizedTypeReference<RetrieveOpenShipmentOutputVODescription>() {};
        return apiClient.invokeAPI(path, HttpMethod.GET, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
}
