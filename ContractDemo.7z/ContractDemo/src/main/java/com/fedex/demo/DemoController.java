package com.fedex.demo;

import java.net.MalformedURLException;
import java.net.URI;

import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.client.model.ShipShipmentInputVO;

@RestController
class DemoController {

	private final RestTemplate restTemplate;
	int port = 8080;

	DemoController(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	@RequestMapping(value="/shipments",consumes="application/json",method=RequestMethod.POST)
	public String shipmentResponse(@RequestBody ShipShipmentInputVO input)  {
		//remove::start[]
		ResponseEntity<String> response = null;
		try {
			response = this.restTemplate.exchange(
					RequestEntity
							.post(URI.create("http://localhost:" + this.port + "/shipCal/v4/shipments"))
							.contentType(MediaType.APPLICATION_JSON)
							.body(new ObjectMapper().writeValueAsString(input)),String.class);
		} catch (RestClientException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}catch (Exception e) {
			System.out.println("Exception in shipmentResponse");
			e.printStackTrace();
		}
	return response.getBody();
	}
	
	
}
