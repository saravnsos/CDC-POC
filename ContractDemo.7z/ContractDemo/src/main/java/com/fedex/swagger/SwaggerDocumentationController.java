package com.fedex.swagger;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.client.model.ShipShipmentInputVO;
import io.swagger.v3.oas.annotations.Operation;

@RestController
public class SwaggerDocumentationController {

	
	@Operation(description="addressLookup service",responses={@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode="404",description="Resource Not Found")})
	@GetMapping("/addressLookup")
	public String getAddress(@RequestBody ShipShipmentInputVO input){
		return "";
		}
}
