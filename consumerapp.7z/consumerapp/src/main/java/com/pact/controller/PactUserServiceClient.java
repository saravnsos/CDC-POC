package com.pact.controller;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

public class PactUserServiceClient {

	private final RestTemplate restTemplate; 
	
	public PactUserServiceClient() {
		
		this.restTemplate= new RestTemplateBuilder().rootUri("http://localhost:8080/").build();
	}
	
	
	
	
	
	
	public String shipments(String input)
	{
		String response=null;
		try {
			System.out.println("Shipments"+input);
			HttpHeaders headers=new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			org.springframework.http.HttpEntity<?> httpEntity= new org.springframework.http.HttpEntity<Object>(input,headers);
			response=restTemplate.exchange("/shipcal/v4/shipments",HttpMethod.POST,httpEntity,String.class).getBody();
		} catch (RestClientException e) {
			
			e.printStackTrace();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return response;
	}
	
	
}
