package io.swagger.client.api;

import io.swagger.client.ApiClient;

import io.swagger.client.model.CancelDeliveryOptionInputVO;
import io.swagger.client.model.CancelDeliveryOptionOutputVO;
import io.swagger.client.model.CreateHoldAtLocationInputVO;
import io.swagger.client.model.CreateHoldAtLocationOutputVO;
import io.swagger.client.model.ElectronicSignatureOptionInputVO;
import io.swagger.client.model.ElectronicSignatureOptionOutputVO;
import io.swagger.client.model.RerouteDeliveryOptionInputVO;
import io.swagger.client.model.RerouteDeliveryOptionOutputVO;
import io.swagger.client.model.ScheduleDeliveryOptionInputVO;
import io.swagger.client.model.ScheduleDeliveryOptionOutputVO;
import io.swagger.client.model.ValidateHoldAtLocationInputVO;
import io.swagger.client.model.ValidateHoldAtLocationOutputVO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2019-06-17T13:18:14.655+05:30")
@Component("io.swagger.client.api.DeliveryOptionControllerV3Api")
public class DeliveryOptionControllerV3Api {
    private ApiClient apiClient;

    public DeliveryOptionControllerV3Api() {
        this(new ApiClient());
    }

    @Autowired
    public DeliveryOptionControllerV3Api(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * cancelDeliveryOption
     * 
     * <p><b>200</b> - Success
     * <p><b>201</b> - Created
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param input input
     * @return CancelDeliveryOptionOutputVO
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public CancelDeliveryOptionOutputVO cancelDeliveryOptionUsingPOST(CancelDeliveryOptionInputVO input) throws RestClientException {
        Object postBody = input;
        
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/deliveryoptions/cancel").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<CancelDeliveryOptionOutputVO> returnType = new ParameterizedTypeReference<CancelDeliveryOptionOutputVO>() {};
        return apiClient.invokeAPI(path, HttpMethod.POST, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * electronicSignatureDeliveryOption
     * 
     * <p><b>200</b> - Success
     * <p><b>201</b> - Created
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param input input
     * @return ElectronicSignatureOptionOutputVO
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public ElectronicSignatureOptionOutputVO electronicSignatureDeliveryOptionUsingPOST(ElectronicSignatureOptionInputVO input) throws RestClientException {
        Object postBody = input;
        
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/deliveryoptions/electronicsignature").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<ElectronicSignatureOptionOutputVO> returnType = new ParameterizedTypeReference<ElectronicSignatureOptionOutputVO>() {};
        return apiClient.invokeAPI(path, HttpMethod.POST, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * holdAtLocationDeliveryOption
     * 
     * <p><b>200</b> - Success
     * <p><b>201</b> - Created
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param input input
     * @return CreateHoldAtLocationOutputVO
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public CreateHoldAtLocationOutputVO holdAtLocationDeliveryOptionUsingPOST(CreateHoldAtLocationInputVO input) throws RestClientException {
        Object postBody = input;
        
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/deliveryoptions/holdatlocation").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<CreateHoldAtLocationOutputVO> returnType = new ParameterizedTypeReference<CreateHoldAtLocationOutputVO>() {};
        return apiClient.invokeAPI(path, HttpMethod.POST, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * rerouteDeliveryOption
     * 
     * <p><b>200</b> - Success
     * <p><b>201</b> - Created
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param input input
     * @return RerouteDeliveryOptionOutputVO
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public RerouteDeliveryOptionOutputVO rerouteDeliveryOptionUsingPOST(RerouteDeliveryOptionInputVO input) throws RestClientException {
        Object postBody = input;
        
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/deliveryoptions/reroute").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<RerouteDeliveryOptionOutputVO> returnType = new ParameterizedTypeReference<RerouteDeliveryOptionOutputVO>() {};
        return apiClient.invokeAPI(path, HttpMethod.POST, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * scheduleDeliveryOption
     * 
     * <p><b>200</b> - Success
     * <p><b>201</b> - Created
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param input input
     * @return ScheduleDeliveryOptionOutputVO
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public ScheduleDeliveryOptionOutputVO scheduleDeliveryOptionUsingPOST(ScheduleDeliveryOptionInputVO input) throws RestClientException {
        Object postBody = input;
        
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/deliveryoptions/schedule").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<ScheduleDeliveryOptionOutputVO> returnType = new ParameterizedTypeReference<ScheduleDeliveryOptionOutputVO>() {};
        return apiClient.invokeAPI(path, HttpMethod.POST, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * validateHoldAtLocationDeliveryOption
     * 
     * <p><b>200</b> - Success
     * <p><b>201</b> - Created
     * <p><b>401</b> - Unauthorized
     * <p><b>403</b> - Forbidden
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Failure
     * @param input input
     * @return ValidateHoldAtLocationOutputVO
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public ValidateHoldAtLocationOutputVO validateHoldAtLocationDeliveryOptionUsingPOST(ValidateHoldAtLocationInputVO input) throws RestClientException {
        Object postBody = input;
        
        String path = UriComponentsBuilder.fromPath("/shipCal/v3/deliveryoptions/validateholdatlocation").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] accepts = { 
            "*/*"
        };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = { 
            "application/json"
        };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<ValidateHoldAtLocationOutputVO> returnType = new ParameterizedTypeReference<ValidateHoldAtLocationOutputVO>() {};
        return apiClient.invokeAPI(path, HttpMethod.POST, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
}
