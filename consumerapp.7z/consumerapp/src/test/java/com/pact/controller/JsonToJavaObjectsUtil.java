package com.pact.controller;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import com.google.gson.Gson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import wiremock.net.minidev.json.parser.JSONParser;

public class JsonToJavaObjectsUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(JsonToJavaObjectsUtil.class);
	
	private JsonToJavaObjectsUtil() {

	}

	public static ObjectMapper getObjectMapper() {

		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.configure(
				DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		objectMapper
				.configure(
						DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT,
						true);

		return objectMapper;
	}

	public static <T> Object getWithObjectMapper(Class<T> clas,String jsonFilePath) throws Exception {
		Object output = null;
		ObjectMapper objectMapper = getObjectMapper();
		Resource resource = new ClassPathResource(jsonFilePath);
		try {
			File file=resource.getFile();
			output = objectMapper.readValue(file, clas);

		} catch (JsonParseException e) {			
			LOGGER.error("JsonToJavaObjectsUtil getWithObjectMapper JsonParseException :: ", e);
		} catch (JsonMappingException me) {
			LOGGER.error("JsonToJavaObjectsUtil getWithObjectMapper JsonMappingException :: ", me);
		} catch (IOException ioe) {
			LOGGER.error("JsonToJavaObjectsUtil getWithObjectMapper IOException :: ", ioe);
		}
		return output;
	}
	
	public static <T> Object getObjectFromJsonString(Class<T> clas,String jsonString) throws Exception {
		Object output = null;
		ObjectMapper objectMapper = getObjectMapper();
		try {
			output = objectMapper.readValue(jsonString, clas);

		} catch (JsonParseException e) {			
			LOGGER.error("JsonToJavaObjectsUtil getWithObjectMapper JsonParseException :: ", e);
		} catch (JsonMappingException me) {
			LOGGER.error("JsonToJavaObjectsUtil getWithObjectMapper JsonMappingException :: ", me);
		} catch (IOException ioe) {
			LOGGER.error("JsonToJavaObjectsUtil getWithObjectMapper IOException :: ", ioe);
		}
		return output;
	}

	public static String readJSONAsString(String jsonFilePath) throws Exception {
        String str= null;
		Resource resource = new ClassPathResource(jsonFilePath);
		try {
			JSONParser parser = new JSONParser();
			File file=resource.getFile();
			Gson gson = new Gson();
			Object object = parser.parse(new FileReader(file));
			str = object.toString();

		} catch (JsonParseException e) {
			LOGGER.error("JsonToJavaObjectsUtil getWithObjectMapper JsonParseException :: ", e);
		} catch (JsonMappingException me) {
			LOGGER.error("JsonToJavaObjectsUtil getWithObjectMapper JsonMappingException :: ", me);
		} catch (IOException ioe) {
			LOGGER.error("JsonToJavaObjectsUtil getWithObjectMapper IOException :: ", ioe);
		}
		return str;
	}

}
