package com.pact.controller;


import java.util.HashMap;
import java.util.Map;

//import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.PactProviderRuleMk2;
import au.com.dius.pact.consumer.PactVerification;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.model.RequestResponsePact;
import io.swagger.client.model.ShipShipmentInputVO;
import io.swagger.client.model.ShipShipmentOutputVO;
import io.swagger.client.model.TransactionShipmentOutputVO;
import wiremock.com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=SpringBootTest.WebEnvironment.NONE,classes=PactUserServiceClient.class)
public class PactConsumerContractTest {
	
	@Autowired
	PactUserServiceClient pactUserServiceClient;
	
	@Rule
	public PactProviderRuleMk2 provider=new PactProviderRuleMk2("shipmentService", "localhost", 8080, this);
	
	
	
	@Pact(consumer="shipmentConsumer")
	public RequestResponsePact createShipments(PactDslWithProvider builder) throws Exception
	{
		ShipShipmentInputVO input=new ShipShipmentInputVO();
		ShipShipmentOutputVO output=new ShipShipmentOutputVO();
		TransactionShipmentOutputVO  transactionShipment=new TransactionShipmentOutputVO();
		transactionShipment.setBookingNumber("B1234567");
		transactionShipment.setReturnShipment(true);
		output.addTransactionShipmentsItem(transactionShipment);
		input=(ShipShipmentInputVO)JsonToJavaObjectsUtil.getWithObjectMapper(ShipShipmentInputVO.class, "shipmentrequest.json");
		Map<String,String> contentHeaders=new HashMap<String, String>();
		contentHeaders.put("Content-Type", "application/json");
		return builder.uponReceiving("SHPC contract testing").path("/shipcal/v4/shipments").method("POST").headers(contentHeaders).body(new ObjectMapper().writeValueAsString(input)).
				willRespondWith().status(200).headers(contentHeaders).body(new ObjectMapper().writeValueAsString(output)).toPact();
		
	}
	
	
	@PactVerification
	@Test
	
	public void testShipments()
	{
		ShipShipmentInputVO input=new ShipShipmentInputVO();
	
		try {
			input=(ShipShipmentInputVO)JsonToJavaObjectsUtil.getWithObjectMapper(ShipShipmentInputVO.class, "shipmentrequest.json");
		String response=	 pactUserServiceClient.shipments(new ObjectMapper().writeValueAsString(input));
		System.out.println("Response:"+response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	@Test
	@PactVerification
	public void testConsumer()
	{
		RestTemplate restTemplate=new RestTemplate();
		
		ShipShipmentInputVO input=new ShipShipmentInputVO();
		try {
			input=(ShipShipmentInputVO)JsonToJavaObjectsUtil.getWithObjectMapper(ShipShipmentInputVO.class, "shipmentrequest.json");
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		HttpHeaders headers=new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		org.springframework.http.HttpEntity<?> httpEntity= new org.springframework.http.HttpEntity<Object>(input,headers);
		ResponseEntity<String> response=restTemplate.exchange("http://localhost:8080/shipcal/v4/shipments",HttpMethod.POST,httpEntity,String.class);
		System.out.println("Response:"+response.getBody());
	}
}
